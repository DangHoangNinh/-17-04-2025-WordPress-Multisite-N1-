<?php
/**
 * Template Name: Home Page
 */

get_header(); ?>
</div>
	<div class="box-wrapper">
		<div class="container_12 primary_content_wrap clearfix">
		<?php if ( ! dynamic_sidebar( 'Before Content Area' ) ) : ?>
		  <!--Widgetized 'Before Content Area' for the home page-->
		<?php endif ?>
		</div>
		<div class="box1"></div>
	</div>
<div class="container_12 primary_content_wrap2 clearfix">
	<?php if ( ! dynamic_sidebar( 'Primary Content Area' ) ) : ?>
	  <!--Widgetized 'Primary Content Area' for the home page-->
	<?php endif ?>
</div>
<div class="box-wrapper2">
	<div class="container_12 primary_content_wrap clearfix">
		<?php if ( ! dynamic_sidebar( 'Secondary Content Area' ) ) : ?>
		  <!--Widgetized 'Secondary Content Area' for the home page-->
		<?php endif ?>
	</div>
</div>
<?php get_footer(); ?>