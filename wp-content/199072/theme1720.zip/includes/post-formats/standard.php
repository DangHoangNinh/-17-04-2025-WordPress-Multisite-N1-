<?php if(!is_singular()) : ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class('post-holder'); ?>>

				<?php get_template_part('includes/post-formats/post-thumb'); ?>
				
				
				<div class="extra-wrap">
				
					<header class="entry-header">
					
					<?php if(!is_singular()) : ?>
					
					<div class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php _e('Permalink to:', 'theme1720');?> <?php the_title(); ?>"><strong><?php the_title(); ?></strong></a></div>
					
					<?php else :?>
					
					<div class="entry-title"><strong><?php the_title(); ?></strong></div>
					
					<?php endif; ?>
					
					<?php get_template_part('includes/post-formats/post-meta'); ?>
					
					</header>
					
					<?php if(!is_singular()) : ?>
					
					<div class="post-content">
						<?php $post_excerpt = of_get_option('post_excerpt'); ?>
						<?php if ($post_excerpt=='true' || $post_excerpt=='') { ?>
							<div class="excerpt"><?php $excerpt = get_the_excerpt(); echo my_string_limit_words($excerpt,50);?></div>
						<?php } ?>
						<a href="<?php the_permalink() ?>" class="button"><?php _e('more', 'theme1720'); ?></a>
					</div>
					
					<?php else :?>
					
					<div class="content">
					
						<?php the_content(''); ?>
						
					<!--// .content -->
					</div>
					
					<?php endif; ?>
					
					<footer class="post-footer">
						<?php the_tags('Tags: ', ' ', ''); ?>
					</footer>
				</div>
			 
			</article>	

<?php else :?>

			<article id="post-<?php the_ID(); ?>" <?php post_class('post-holder'); ?>>
				<div class="singlepost">
					<header class="entry-header">
					
					<?php if(!is_singular()) : ?>
					
					<h4 class="entry-title"><a href="<?php the_permalink(); ?>" title="<?php _e('Permalink to:', 'theme1720');?> <?php the_title(); ?>"><?php the_title(); ?></a></h4>
					
					<?php else :?>
					
					<h4 class="entry-title"><?php the_title(); ?></h4>
					
					<?php endif; ?>
					
					<?php get_template_part('includes/post-formats/post-meta'); ?>
					
					</header>

					<?php get_template_part('includes/post-formats/post-thumb'); ?>
					
					<?php if(!is_singular()) : ?>
					
					<div class="post-content">
						<?php $post_excerpt = of_get_option('post_excerpt'); ?>
						<?php if ($post_excerpt=='true' || $post_excerpt=='') { ?>
							<div class="excerpt"><?php $excerpt = get_the_excerpt(); echo my_string_limit_words($excerpt,50);?></div>
						<?php } ?>
						<a href="<?php the_permalink() ?>" class="button"><?php _e('more', 'theme1720'); ?></a>
					</div>
					
					<?php else :?>
					
					<div class="content">
					
						<?php the_content(''); ?>
						
					<!--// .content -->
					</div>
					
					<?php endif; ?>
					
					<footer class="post-footer">
						<?php the_tags('Tags: ', ' ', ''); ?>
					</footer>
			 	</div>
			</article>

<?php endif; ?>