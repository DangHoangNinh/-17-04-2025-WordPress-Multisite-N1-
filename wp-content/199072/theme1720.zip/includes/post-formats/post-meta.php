    <?php $post_meta = of_get_option('post_meta'); ?>
		<?php if ($post_meta=='true' || $post_meta=='') { ?>
			<div class="post-meta">
				<strong class="post-date"></strong><span><time datetime="<?php the_time('Y-m-d\TH:i'); ?>"><?php the_time('j-m-Y'); ?></time> </span>
				<strong class="post-author"></strong><span><?php the_author_posts_link() ?></span>
				<strong class="post-comment"></strong><span><?php comments_popup_link('0', '1', '%', 'comments-link', 'Comments are closed'); ?></span>
			</div><!--.post-meta-->
		<?php } ?>		
