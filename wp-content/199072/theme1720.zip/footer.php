</div><!--.container-->
	<footer id="footer">
  	<div id="back-top-wrapper">
    	<p id="back-top">
        <a href="#top"><span></span><?php _e('Back to Top', 'theme1720'); ?></a>
      </p>
    </div>
		<div class="container_12 clearfix">
			<div id="widget-footer" class="clearfix">
			<?php if ( ! dynamic_sidebar( 'Footer' ) ) : ?>
			  <!--Widgetized Footer-->
			<?php endif ?>
		  </div>
			<div id="copyright" class="clearfix">
				<div class="grid_12">
					<?php if ( of_get_option('footer_menu') == 'true') { ?>  
						<nav class="footer">
							<?php wp_nav_menu( array(
								'container'       => 'ul', 
								'menu_class'      => 'footer-nav', 
								'depth'           => 0,
								'theme_location' => 'footer_menu' 
								)); 
							?>
						</nav>
					<?php } ?>
					<div id="footer-text">
						<?php $myfooter_text = of_get_option('footer_text'); ?>
						
						<?php if($myfooter_text){?>
							<?php echo of_get_option('footer_text'); ?>
						<?php } else { ?>© 2012 • <a href="<?php bloginfo('url'); ?>/privacy-policy/" title="Privacy Policy"><?php _e('Privacy Policy', 'theme1720'); ?></a>
						<?php } ?>
						<?php if( is_front_page() ) { ?>
						<!-- {%FOOTER_LINK} -->
						<?php } ?>
					</div>
					
				</div>
			</div>
		</div><!--.container-->
	</footer>
<?php wp_footer(); ?> <!-- this is used by many Wordpress features and for plugins to work properly -->
<?php if(of_get_option('ga_code')) { ?>
	<script type="text/javascript">
		<?php echo stripslashes(of_get_option('ga_code')); ?>
	</script>
  <!-- Show Google Analytics -->	
<?php } ?>
</body>
</html>